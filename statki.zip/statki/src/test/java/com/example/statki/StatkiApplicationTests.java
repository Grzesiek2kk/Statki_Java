package com.example.statki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatkiApplicationTests {

	@Test
	void contextLoads() {
	}

}
