package com.example.statki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class StatkiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StatkiApplication.class, args);
	}

}
